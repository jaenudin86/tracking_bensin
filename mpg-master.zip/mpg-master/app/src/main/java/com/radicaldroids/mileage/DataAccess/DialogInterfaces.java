package com.radicaldroids.mileage.DataAccess;

/**
 * Created by Andrew on 10/28/2015.
 */
public class DialogInterfaces {
    public interface DialogInterface{
        void fabAdd();
        void openEditVehicleEntryFragment();
        void dismissDialogFragment(String tag);
        void updateToolBarView();
    }
}

