package com.radicaldroids.mileage;

/**
 * Created by Andrew on 4/28/2016.
 */
public class Constants {

    public static final String SHARED_PREFS ="prefs";
    public static final String SHARED_PREFS_CURRENT_VEHICLE ="currentVehicle";
    public static final String SHARED_PREFS_CURRENT_VEHICLE_GUI ="currentVehicleGUI";

    public static final String WIDGET_UPDATE="WIDGET_UPDATE";

}
