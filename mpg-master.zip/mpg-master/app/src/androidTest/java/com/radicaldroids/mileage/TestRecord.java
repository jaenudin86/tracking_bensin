package com.radicaldroids.mileage;

/**
 * Created by Andrew on 1/9/2017.
 */

public class TestRecord {

    private String station;
    private String mileage;
    private String gallons;
    private String price;

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getGallons() {
        return gallons;
    }

    public void setGallons(String gallons) {
        this.gallons = gallons;
    }

    public String getMileage() {
        return mileage;
    }

    public void setMileage(String mileage) {
        this.mileage = mileage;
    }
}
