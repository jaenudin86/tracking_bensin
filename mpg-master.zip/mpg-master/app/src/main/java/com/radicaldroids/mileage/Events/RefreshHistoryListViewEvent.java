package com.radicaldroids.mileage.Events;

/**
 * Created by Andrew on 10/14/2015.
 */
public class RefreshHistoryListViewEvent {
    public final String message;
    public RefreshHistoryListViewEvent(String message){
        this.message = message;
    }
}
