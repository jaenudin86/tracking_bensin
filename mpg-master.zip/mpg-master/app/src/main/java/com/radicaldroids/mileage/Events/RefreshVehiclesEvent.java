package com.radicaldroids.mileage.Events;

/**
 * Created by Andrew on 12/9/2015.
 */
public class RefreshVehiclesEvent {
    public RefreshVehiclesEvent(){
    }
}
