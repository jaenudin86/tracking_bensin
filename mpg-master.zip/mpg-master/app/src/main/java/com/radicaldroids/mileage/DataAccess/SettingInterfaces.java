package com.radicaldroids.mileage.DataAccess;

/**
 * Created by Andrew on 12/21/2015.
 */
public class SettingInterfaces {
    public interface SettingInterface{
        void openVehicleListFragment();
    }
}
